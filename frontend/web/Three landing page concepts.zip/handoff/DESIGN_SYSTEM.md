# GitBounty — Design System (Direction B: "Broadsheet")

Dark, editorial, ledger-like. Big grotesk headlines, mono metadata, hairline rules, one acid-green accent used only for **points, primary actions, and progress**. Reference implementation: `GitBountyLanding.jsx`.

---

## 1. Principles
1. **Evidence over hype.** Show real-looking artifacts (issues, diffs, receipts, logs) instead of illustrations, icons, or stats.
2. **Green means earned.** `#B7F34A` is reserved for points values, primary CTAs, active state, and progress bars. Never decorative.
3. **Rules, not boxes.** Structure with 1px hairlines and grid columns. Cards are rare (receipt, extension mock, how-it-works panel).
4. **Honest copy.** Points are recognition, *not* money/tokens. Unfinished safeguards are labeled "open work" / "before launch".
5. **Everything on GitHub stays on GitHub.** Never imply a replacement workflow.

---

## 2. Color tokens

| Token | Hex | Use |
|---|---|---|
| `--bg` | `#080B09` | Page background |
| `--surface` | `#0D110E` | Alternate section bg, inputs, panels |
| `--surface-hover` | `#111713` | Row hover |
| `--surface-raised` | `#172019` | Skeletons, diff-add bg, avatars |
| `--line-subtle` | `#202923` | Row dividers inside lists |
| `--line` | `#303C33` | Section borders, input borders |
| `--line-strong` | `#465449` | Table top rules, outline buttons, chips |
| `--text` | `#F2F6EF` | Primary text |
| `--text-muted` | `#AAB5AB` | Body copy, secondary text (≥4.5:1 on bg) |
| `--text-faint` | `#707C72` | Metadata, captions, labels only (not body) |
| `--accent` | `#B7F34A` | Points, primary CTA, active, progress |
| `--accent-hover` | `#9DDD32` | Primary CTA hover |
| `--accent-tint` | `#172B12` | Active chip bg, highlighted "you" row, earned row |
| `--focus` | `#D7FF8F` | Focus ring |
| `--success` | `#3DDB82` | Diff additions, "✓ enforced", open-issue glyph |
| `--paper` | `#F2F6EF` | Receipt background (ink = `--bg`) |

```css
:root{
  --bg:#080B09; --surface:#0D110E; --surface-hover:#111713; --surface-raised:#172019;
  --line-subtle:#202923; --line:#303C33; --line-strong:#465449;
  --text:#F2F6EF; --text-muted:#AAB5AB; --text-faint:#707C72;
  --accent:#B7F34A; --accent-hover:#9DDD32; --accent-tint:#172B12;
  --focus:#D7FF8F; --success:#3DDB82; --paper:#F2F6EF;
}
```
Text on `--accent` is always `--bg` (`#080B09`). Selection: accent bg, bg-colored text.

---

## 3. Typography

| Role | Family | Weight | Size | Line-height | Tracking |
|---|---|---|---|---|---|
| Display (hero H1) | Space Grotesk | 600 | `clamp(46px, 7.4vw, 96px)` | 0.94 | -0.045em |
| CTA display | Space Grotesk | 700 | `clamp(50px, 9vw, 136px)` | 0.90 | -0.05em |
| Manifesto | Space Grotesk | 500 | `clamp(36px, 5.6vw, 80px)` | 1.0 | -0.04em |
| H2 section | Space Grotesk | 600 | `clamp(36px, 4.6vw, 64px)` | 1.0 | -0.035em |
| H3 / card title | Space Grotesk | 500 | 22–34px | 1.1–1.25 | -0.02em |
| Body large | Inter | 400 | 17–19px | 1.6 | 0 |
| Body / UI | Inter | 400–600 | 14–17px | 1.45–1.6 | 0 |
| Mono metadata | JetBrains Mono | 400–600 | 11–14px | 1.5–1.9 | 0 (UPPERCASE for labels) |
| Mono number (points) | JetBrains Mono | 600 | 16–28px | 1 | 0 |

Fonts: `Space Grotesk 400–700`, `Inter 400–600`, `JetBrains Mono 400–600` (Google Fonts). Use `text-wrap: pretty` on body paragraphs; max measure ~30–34em.

**Mono is for data**: repo names, issue/PR numbers, SHAs, timestamps, labels, eyebrow labels (`THE OPEN-SOURCE LEDGER`), point values.

---

## 4. Layout & spacing
- Container: `max-width: 1320px; margin: 0 auto; padding-inline: clamp(20px, 4vw, 56px)`.
- Section padding: `clamp(64px, 8vw, 112px)` vertical (hero/manifesto/CTA larger: up to 176–200px).
- Sections separated by `border-top: 1px solid var(--line)`; alternate bg `--surface` for rhythm (How, Leaderboard, Architecture).
- Spacing scale (px): 4, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80.
- Layout = flex-wrap / `grid auto-fit minmax(min(100%, Npx), 1fr)` — no fixed breakpoints for content.
- JS breakpoints: `>= 900px` "wide" (desktop tables/extra columns); `>= 1120px` full nav (below → Menu button).
- Radii: **2px** default (buttons, inputs, tags), 4px panels, 6px browser mock, `999px` pills only for labels.
- No shadows. No gradients.

---

## 5. Components

**Header** — sticky, 60px. Transparent at top; on scroll `rgba(8,11,9,.88)` + `backdrop-filter: blur(10px)` + bottom border `--line-subtle`. Logo `[+]` in accent mono + "GitBounty" Space Grotesk 700 17px. Nav links mono 12.5px `--text-muted`. Mobile: "Menu"/"Close" button (44px) toggles a stacked nav with full-width primary CTA.

**Buttons**
- Primary: bg accent, text bg, Inter 600 15–16px, min-height 48–52px, padding 0 20–24px, radius 2px; hover `--accent-hover`.
- Secondary: 1px `--line-strong` border, text `--text`; hover border `--text-muted`.
- Text link CTA: bottom border `--line-strong`; hover color accent.
- Small toggle (segmented): min-height 40px, 1px `--line` border; active = accent bg (range) or muted bg (demo state). Use `aria-pressed`.

**Eyebrow bar** — mono 11.5px `--text-faint`, justified left/right, bottom 1px `--line`.

**Contribution strip (hero)** — 6-column auto-fit list (ISSUE → CODE → PULL REQUEST → MERGE → POINTS → REPUTATION), top rule `--line-strong` with a 3px accent progress bar animated across; cells separated by `--line-subtle`. Unreached cells at opacity 0.14.

**Issue explorer** — left filter rail (search, sort select, category list with 2px left-border active indicator + mono count) and results list. Row: mono repo + #num + stars/updated, Space Grotesk title 18–22px, mono labels separated by "·", right-aligned points (accent if issue value set, muted "+5 base" otherwise) + "View issue →". Row hover `--surface`. States required: loading (skeleton bars `--surface-raised`, fading opacity), empty (message + Clear filters), error (mono error code + Retry). *The "Preview state" toggle in the reference is a design demo — remove in production.*

**Tabs (How it works)** — 4 columns, top rule with 2px accent progress; inactive opacity 0.4. Panel: big step word (Space Grotesk up to 88px) + mono artifact rows that reveal as steps advance. `role="tablist" / "tab" / "tabpanel"`.

**Receipt** — paper bg `#F2F6EF`, ink `#080B09`, mono 13.5px, max-width 520px, dashed separator, 2px solid total rule, total value highlighted with accent bg.

**Label chip** — mono 11px, 1px border, pill radius. Point labels format: `gitbounty:40`.

**Category grid** — auto-fit tiles (min 280px, aspect ~1.35), hairline borders, number + open count top, name + file glob bottom; hover bg `--surface`.

**Leaderboard** — mono rows: rank (faint), username (Space Grotesk 20px) + category · merges (faint), points (accent 600), movement ▲ accent / ▼ muted / — faint (with `aria-label`). "You" row: `--accent-tint` bg + 2px accent top border.

**Audit table (Integrity)** — bordered 4px panel, header row `--surface`, statuses `✓ enforced` (success) / `○ open work` (muted).

**Extension mock** — browser chrome bar (mono URL pill), GitHub-like issue rows with a `GB +60 · BACKEND` tag (accent-tint bg for valued, outline for base).

**FAQ** — accordion, question Space Grotesk 500 18–22px, `+/−` mono indicator, `aria-expanded` + `aria-controls`; one open at a time.

**Footer** — logo + tagline, inline link row, mono build line (`EOF · gitbounty-web v0.9.0`).

---

## 6. Motion
- Easing: `cubic-bezier(.2,.7,.2,1)`.
- Durations: 160ms (hover color/border), 180ms (header, status color), 420–480ms (step reveal opacity), 560ms (section reveal), 600ms (progress width), 650ms (points count-up, ease-out cubic).
- Hero sequence: auto-advances every ~1050ms through 6 stages, points count 0 → 45, holds 7s, loops.
- Section reveal: elements below the fold with `data-reveal` fade + translateY(16px) → 0 once via IntersectionObserver.
- `prefers-reduced-motion: reduce` → no smooth scroll, no transitions, hero shown at final state.

---

## 7. Accessibility
- Body text ≥ 4.5:1 (`--text` / `--text-muted` on `--bg`/`--surface`). `--text-faint` only for non-essential metadata.
- Focus: `outline: 2px solid #D7FF8F; outline-offset: 2px` on `:focus-visible`.
- Hit targets ≥ 44px on mobile.
- Toggle buttons use `aria-pressed`; accordion `aria-expanded`; live result counts `aria-live="polite"`; decorative glyphs `aria-hidden`.

---

## 8. Copy rules
- Voice: plain, confident, technical. Short declaratives ("Stop searching at random.").
- Always: "points" (never bounty money, rewards, tokens, earnings in $).
- Point math is explicit: `+5 base merge reward` + `issue value` = total.
- Label sample data as sample ("Sample data · illustrative repositories").
- Unreleased things are tagged: `OPTIONAL EXTENSION · NOT YET RELEASED`.

---

## 9. Implementation notes (for the reference JSX)
- `GitBountyLanding.jsx` is a single default-export React component (React 18, no other deps). Styles are inline objects; `:hover` rules live in the `CSS` string as `.gbhN` classes.
- `ISSUES`, `LEAD`, `FAQ`, `TAXO` are sample data — swap for API calls. `vals()` derives all view state (filtering, sorting, leaderboard ranges).
- Recommended refactor when integrating: move tokens to CSS variables (§2), split sections into components (`Header`, `Hero`, `Explorer`, `HowItWorks`, `Receipt`, `Leaderboard`, `FAQ`, `Footer`), replace the `c.gb` state object with `useState`/`useReducer`.
